# Multi-Protocol Honeypot with Web Dashboard

Emulated protocols: **HTTP, FTP, SSH, SNMP, SMB, Telnet** — each is a real
listening socket that speaks enough of the protocol to be correctly
fingerprinted by tools like `nmap -sV`, logs every connection/command/
credential attempt to SQLite, and can be started/stopped/re-bannered live
from a web GUI.

## 1. Install (Windows)

```powershell
cd honeypot
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

`paramiko` is optional — without it, the SSH honeypot still presents a
correct `SSH-2.0-...` banner (enough for nmap/banner-grabbers) but won't
run a full fake login shell.

## 2. Run

```powershell
cd web
python app.py
```

Open `http://localhost:5000` — first visit routes you to `/setup` to create
the dashboard's admin username/password (hashed with Werkzeug, stored in
`logs/state.json`). After that, every visit requires login.

## 3. Ports & why they're not the "real" well-known ports by default

Binding to ports below 1024 (80, 21, 22, 23, 445, 161) requires
Administrator privileges on Windows, **and** those ports are usually
already in use by Windows' own services (e.g. SMB on 445 is used by the
OS itself). Defaults here use high ports instead:

| Protocol | Default port | Real port |
|---|---|---|
| HTTP   | 8080 | 80 |
| FTP    | 2121 | 21 |
| SSH    | 2222 | 22 |
| Telnet | 2323 | 23 |
| SMB    | 4450 | 445 |
| SNMP   | 1610/udp | 161/udp |

To actually expose the standard ports so an `nmap` scan from another host
sees them as `21/tcp open ftp`, etc.:
1. Run `python app.py` as Administrator.
2. Edit `core/config.py` → `DEFAULT_PORTS` and set the real port numbers.
3. Make sure nothing else on the machine is using that port (run
   `netstat -ano | findstr :445` etc. first) — you may need to disable the
   Windows SMB server (`Server` service) or Windows' own FTP/Telnet
   features if enabled, and open the port in Windows Firewall
   (`New-NetFirewallRule -DisplayName "Honeypot FTP" -Direction Inbound -LocalPort 21 -Protocol TCP -Action Allow`).

## 4. Banners

`core/config.py` → `BANNER_PROFILES` has several predefined, plausible
"vulnerable-looking" banners per protocol (e.g. vsftpd 2.3.4, OpenSSH 5.3,
Apache 2.2.8). Switch the active one per protocol live from the dashboard's
dropdown — the service restarts automatically with the new banner.

## 5. Logs

All events (connect/disconnect/commands/errors) and captured
username/password or SNMP community-string attempts go to
`logs/honeypot.db` (SQLite). Use the dashboard's export button
(`/api/export`) to download the full log set as JSON at any time.

## 6. Architecture

```
honeypot/
  core/       config, state (auth+enabled protocols), sqlite logging, manager
  protocols/  one module per protocol, each a threaded socket server
  web/        Flask GUI (auth, live feed, controls) + templates
  logs/       honeypot.db, state.json (created on first run)
```

## 7. Scope & limitations (read before relying on this)

- **SMB and SNMP here are intentionally shallow** (they answer just enough
  to register as open/identified by a scanner and to capture the SNMP
  community string or SMB negotiate request) — they are not full protocol
  stacks. For deep, fully-interactive SMB/SNMP emulation, pair this with
  established projects (e.g. Cowrie for SSH/Telnet, Conpot for
  ICS/SNMP-heavy setups) — this codebase is intentionally self-contained
  and dependency-light so you can extend any single protocol module
  further yourself.
- Never expose this on your real production network without network
  segmentation (a separate VLAN/DMZ) — a honeypot's job is to attract
  attackers, so isolate it from anything sensitive.
- Only deploy honeypots on networks/systems you own or are authorized to
  monitor.
